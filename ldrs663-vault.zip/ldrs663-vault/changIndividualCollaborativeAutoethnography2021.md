---
DOI:
  "{ DOI }": 
Date:
  "{ date | format (YYYY) }": 
Rating: 0/5
tags: 
pdf: "changIndividualCollaborativeAutoethnography2021.pdf"
created: 2024-06-05T07:58
updated: 2024-09-06T11:10
---


#### [Individual and Collaborative Autoethnography for Social Science Research](changIndividualCollaborativeAutoethnography2021.pdf)


> [!tldr] Summary
> A short summary - or an abstract in 3 sentences, relating to YOU. What did YOU find interesting about this paper. 

> [!cite] Bibliography
>Chang, H. (2021). Individual and Collaborative Autoethnography for Social Science Research. In T. E. Adams, S. H. Jones, & C. Ellis (Eds.), _Handbook of Autoethnography_ (2nd ed., pp. 53–65). Routledge. [https://doi.org/10.4324/9780429431760-6](https://doi.org/10.4324/9780429431760-6)

> [!quote] Quotable
> Imagine you would quote this paper in your publication. How would you do it? It is probably just one sentence followed by the reference. It is the most intense condensation of the information in this paper and forces you to be on point. 
> 
> You can have multiple alternatives. 


#### Related

#### Annotations





