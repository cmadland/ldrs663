---
created: 2023-11-21T16:30
updated: 2023-11-21T16:30
---
analyze the characteristics of the coaching role within theoretical models of blended teaching and learning