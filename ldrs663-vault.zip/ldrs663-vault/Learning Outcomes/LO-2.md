---
created: 2023-11-21T16:31
updated: 2023-11-21T16:31
---
demonstrate the ability to model metacognitive strategies for self-regulated learning