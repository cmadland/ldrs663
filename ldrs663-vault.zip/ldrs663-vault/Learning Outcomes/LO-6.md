---
created: 2023-11-21T16:32
updated: 2023-11-21T16:32
---
Design cognitive and social activities to meet learning outcomes