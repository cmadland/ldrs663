---
tool name: 
use rating: " /5"
privacy rating: " /5"
url:
---


> [!tldr] Summary
> A short summary of how this tool is useful to you in your digital workflow.


> [!danger] Privacy and Data
> - What data are collected during the use of the tool?
> - How are those data used by the developers of the tool?
> - Who owns the rights to artifacts created with the tool?

> [!notes]