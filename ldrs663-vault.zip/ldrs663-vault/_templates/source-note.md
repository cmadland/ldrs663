---
DOI:
  "{ DOI }": 
Date:
  "{ date | format (YYYY) }": 
Rating: 0/5
tags: 
pdf: "{{citekey}}.pdf"
created: 2024-06-05T07:58
updated: 2024-09-06T11:10
---


#### [{{title}}]({{citekey}}.pdf)


> [!tldr] Summary
> A short summary - or an abstract in 3 sentences, relating to YOU. What did YOU find interesting about this paper. 

> [!cite] Bibliography
>{{bibliography}}

> [!quote] Quotable
> Imagine you would quote this paper in your publication. How would you do it? It is probably just one sentence followed by the reference. It is the most intense condensation of the information in this paper and forces you to be on point. 
> 
> You can have multiple alternatives. 


#### Related

#### Annotations





