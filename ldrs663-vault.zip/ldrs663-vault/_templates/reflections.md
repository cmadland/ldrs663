---
created: 2024-09-07T14:18
updated: 2024-09-07T15:09
tags: 
---
> [!tldr] Instructions
> *Please delete these instructions when you compose your post.*
> 
> Use this template to create a new reflection post. Each post should be 300-500 words. Please use tags in your posts, both in the 'Properties' section at the top of the page, and in the body of your post wherever it makes sense.
>
> Your post does not need to conform to strict APA formatting, but you should always include links to citations. These posts are intended to be a place to test your ideas and get feedback to use for refinement. They should reflect a level of academic engagement with the material, but do not need to be perfectly composed.
